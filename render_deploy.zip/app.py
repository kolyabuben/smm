# -*- coding: utf-8 -*-
import os
import sys
import logging
import asyncio
from aiohttp import web

import bot

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

PORT = int(os.getenv("PORT", 10000))

async def handle_ping(request):
    return web.Response(
        text="🟢 SMM Animora Telegram Bot is ACTIVE and RUNNING 24/7 on Render! 🚀\n",
        content_type="text/plain"
    )

async def main():
    # 1. Start HTTP health check server for Render
    app = web.Application()
    app.router.add_get("/", handle_ping)
    app.router.add_get("/health", handle_ping)
    
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", PORT)
    await site.start()
    logger.info(f"Render health server listening on port {PORT}")

    # 2. Start Telegram bot
    await bot.main_async()

if __name__ == "__main__":
    asyncio.run(main())
