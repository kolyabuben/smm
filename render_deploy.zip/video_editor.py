# -*- coding: utf-8 -*-
import os
import subprocess
import config

def render_organic_reel(input_video_path: str, country: str = "Japan", music_type: str = "piano") -> str:
    """
    Renders 9:16 vertical organic Reel in Linux / Docker:
    - Eliminates Kling / AI watermarks via smart aspect-ratio preserving crop (bottom 3.9%)
    - Scales with Lanczos filter to 1080x1920
    - Mixes romantic piano music with smooth audio fade in and fade out
    """
    music_file = config.MUSIC_PIANO if music_type == "piano" else config.MUSIC_WEDDING
    base_name = os.path.splitext(os.path.basename(input_video_path))[0]
    out_name = f"{base_name}_{country}_clean_ready.mp4"
    out_path = os.path.join(config.OUTPUT_DIR, out_name)
    
    filter_complex = (
        "[0:v]crop=in_w*0.961:in_h*0.961:in_w*0.0195:0,scale=1080:1920:flags=lanczos,format=yuv420p[vbase];"
        "[1:a]volume=0.85,afade=t=in:ss=0:d=0.5,afade=t=out:st=4.0:d=1.0[aout]"
    )
    
    cmd = [
        config.FFMPEG_PATH, '-y',
        '-i', input_video_path,
        '-i', music_file,
        '-filter_complex', filter_complex,
        '-map', '[vbase]',
        '-map', '[aout]',
        '-c:v', 'libx264',
        '-preset', 'fast',
        '-crf', '19',
        '-pix_fmt', 'yuv420p',
        '-profile:v', 'high',
        '-level', '4.1',
        '-c:a', 'aac',
        '-b:a', '192k',
        '-movflags', '+faststart',
        '-shortest',
        out_path
    ]
    
    subprocess.run(cmd, check=True)
    return out_path
