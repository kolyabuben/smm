# -*- coding: utf-8 -*-
import os

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "8663419969:AAGHzpAJc2g_GA9tFNbhF6GfblvFcjY-Srg")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "AQ.Ab8RN6JTHlysKq2-1gJ-DhCSmmHkwX3_5_FUK0sjhat4QkmJbg")
GEMINI_MODEL = "gemini-3.5-flash-lite"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INCOMING_DIR = os.path.join(BASE_DIR, "incoming")
OUTPUT_DIR = os.path.join(BASE_DIR, "output")

FFMPEG_PATH = "ffmpeg"
MUSIC_PIANO = os.path.join(BASE_DIR, "music", "romantic_piano.mp3")
MUSIC_WEDDING = os.path.join(BASE_DIR, "music", "wedding_film.mp3")

os.makedirs(INCOMING_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)
