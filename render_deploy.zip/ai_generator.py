# -*- coding: utf-8 -*-
import json
from google import genai
import config

client = genai.Client(api_key=config.GEMINI_API_KEY)

TRENDS_KNOWLEDGE_BASE = """
Актуальные алгоритмические тренды Instagram Reels & TikTok:
1. "The Wingman Pet" (Питомец-сводник / спаситель): Кот или пес провоцирует физический романтический контакт пары (подсекает, заставляет обняться, соединяет руки, крадет вещь и заставляет бежать вместе). Дает максимальный шеринг в директ между влюбленными ("это буквально мы").
2. "Kyun-desu / Accidental Dip" (Замирание сердца / Случайный романтический подхват): Неловкость первого свидания или нерешительность, прерываемая резким кинематографичным действием (падение, подхват в стиле классического Disney, лица в паре сантиметров).
3. "Plot Twist on 7th Second" (Разрыв шаблона): Зритель ожидает ссору, драму или напряжение (0-6с), но на 7-й секунде происходит неожиданный комичный или гипер-милый поворот. Высочайший процент досмотра до конца.
4. "Cute Aggression & Begging" (Манипуляция запредельной милотой): В финале персонаж или кот смотрит в упор в камеру влажными, умоляющими глазами-блюдцами (эффект Кота из Шрека), выпрашивая ласку. Провоцирует тысячи комментариев и пересылок.
5. "Midnight Aesthetic / Street Food" (Неоновый Токио / Уличная романтика Берлина): Пар от рамена, мокрый асфальт, отражения фонариков сакуры, уютные шарфы и свитера, кинематографичный свет.
"""

def generate_viral_ideas(country: str, count: int = 5) -> list:
    """Analyzes real-time algorithmic trends and returns only high-converting trending reel concepts."""
    
    geo_context = (
        "ЯПОНИЯ (Tokyo, Shibuya, Kyoto). Тренды: 胸キュン (Kyun-desu — романтический трепет), 癒やし (Iyashi — исцеляющая милота котиков после работы), Aruaru (жизненные ситуации свиданий)."
        if country == "Japan"
        else "ГЕРМАНИЯ (Berlin, Mitte). Тренды: контраст между урбаном/технологиями (Tesla, рейвы, кофе) и неожиданной уютной романтикой, легкий европейский юмор."
    )

    prompt = f"""
Ты — главный тренд-аналитик и вирусный сценарист алгоритмов Instagram Reels и TikTok (топ-0.1% по охватам).
Бренд: C4 ANIMORA (премиум 3D-анимация в стиле Disney/Pixar).
Твоя задача: отобрать и сформировать ровно {count} САМЫХ ТРЕНДОВЫХ концепций для коротких рилсов (ровно 10 секунд).

База трендов для использования:
{TRENDS_KNOWLEDGE_BASE}

Целевая аудитория и гео:
{geo_context}

Строгие правила трендового отбора:
- Формат: ровно 10 секунд по формуле 100% удержания:
  * 0–3с: Шок-хук (визуальный триггер для остановки скролла в первой секунде).
  * 3–7с: Пик динамики и романтическое взаимодействие пары (люди в кадре обязательны!).
  * 7–10с: Эмоциональный нокаут / вирусный панчлайн (милота, слезящиеся глаза кота, неожиданный финал).
- Никаких скучных банальностей! Каждая идея должна иметь четкую причину, почему алгоритм закинет её в рекомендации.

Верни СТРОГО валидный JSON-массив из {count} объектов:
[
  {{
    "id": 1,
    "trend_tag": "🔥 ТРЕНД: Название тренда/тропа",
    "title": "Цепляющее название идеи",
    "timeline": "0-3с: [Хук]. 3-7с: [Экшен]. 7-10с: [Панчлайн].",
    "why_viral": "Психологический триггер для алгоритма: почему люди нажмут 'Поделиться' и напишут коммент"
  }}
]
"""
    response = client.models.generate_content(
        model=config.GEMINI_MODEL,
        contents=prompt
    )
    raw = response.text.strip()
    if "```json" in raw:
        raw = raw.split("```json")[1].split("```")[0].strip()
    elif "```" in raw:
        raw = raw.split("```")[1].split("```")[0].strip()
    try:
        return json.loads(raw)
    except Exception as e:
        print("JSON parse error in ideas:", e, "Raw text:", raw)
        return [
            {
                "id": 1,
                "trend_tag": "🔥 ТРЕНД: Wingman Pet (Кот-сводник)",
                "title": "Кот крадёт тайяки и заставляет их обняться",
                "timeline": "0-3с: Неловкое свидание в Сибуе, боятся взять за руку. 3-7с: Пушистый кот крадет тайяки, парень спотыкается и ловит девушку в танцевальном наклоне. 7-10с: Кот сидит у ног с тайяки и жалобно строит глазки, прося почесать за ушком.",
                "why_viral": "Триггер «Это буквально мы»: видео отправляют вторым половинкам, провоцируя лавину репостов в директ."
            },
            {
                "id": 2,
                "trend_tag": "⚡ ТРЕНД: Plot Twist на 7-й секунде",
                "title": "Ссора под дождем, которую спас один взгляд",
                "timeline": "0-3с: Девушка обиженно отвернулась под сакурой, парень не знает что делать. 3-7с: Кот выныривает из куртки парня, берет его ладонь и силой вкладывает в руку девушки. 7-10с: Пара улыбается, а кот высовывает мордочку в камеру со слезинками в глазах: «А теперь гладьте меня!».",
                "why_viral": "Разрыв шаблона от драмы к гипер-милоте — удержание 100% зрителей до последней секунды."
            }
        ]

def generate_production_package(country: str, idea_title: str, idea_desc: str) -> dict:
    """Generates the Kling/Flow prompt, native caption, hashtags, and first comment poll."""
    target_lang = "Japanese" if country == "Japan" else "German"
    
    prompt = f"""
Ты ведущий AI-режиссёр и вирусный копирайтер Instagram Reels.
Идея: "{idea_title}"
Сюжет: "{idea_desc}"
Страна: {country} (Язык: {target_lang})

Сгенерируй профессиональный технический пакет:
1. "prompt": Технический кинематографичный промпт на АНГЛИЙСКОМ для Kling AI / Google Flow / Veo:
   - Стиль: Cinematic 3D Disney Pixar feature animation, 9:16 vertical, continuous unbroken shot, 10 seconds.
   - Точные таймкоды: [0-3s], [3-7s], [7-10s].
   - Точная фиксация одежды, причесок и цветов (чтобы не мутировали).
   - Динамика камеры (tracking shot, push-in, tilt-down).
   - Свет (twilight, lantern glow, volumetric fog).
   - БЕЗ слов-триггеров модерации (no 'feet', 'underage', 'bed/sofa couch').
2. "on_screen_hook": Короткий, интригующий хук на {target_lang} языке для наложения на само видео (1 короткая строка).
3. "caption": Вирусный текст описания на {target_lang} языке: эмоциональный, понятный, вовлекающий, с призывом подписаться на ежедневные мультики (@account). БЕЗ прямой рекламы и продаж.
4. "first_comment": Твой первый закрепленный комментарий-опрос с цифрами (①, ②, ③) на {target_lang} языке, заставляющий зрителей спорить и выбирать свой вариант.
5. "hashtags": 8-10 самых высокочастотных вирусных тегов на {target_lang} языке.
6. "russian_summary": Полный русский перевод хука, описания и комментария (чтобы автор понимал точный смысл).

Верни СТРОГО JSON-объект:
{{
  "prompt": "...",
  "on_screen_hook": "...",
  "caption": "...",
  "first_comment": "...",
  "hashtags": "...",
  "russian_summary": "..."
}}
"""
    response = client.models.generate_content(
        model=config.GEMINI_MODEL,
        contents=prompt
    )
    raw = response.text.strip()
    if "```json" in raw:
        raw = raw.split("```json")[1].split("```")[0].strip()
    elif "```" in raw:
        raw = raw.split("```")[1].split("```")[0].strip()
    try:
        return json.loads(raw)
    except Exception as e:
        print("JSON parse error in package:", e, "Raw:", raw)
        return {
            "prompt": f"A vertical 10-second continuous cinematic shot, 9:16 aspect ratio, premium 3D Pixar Disney feature animation style. {idea_desc}",
            "on_screen_hook": "最後まで見たら心奪われます…🥺🐾",
            "caption": "デート中に突然のハプニング…？🥺🌸\n毎日癒やしのショートアニメをお届け中！【フォロー】してね✨",
            "first_comment": "みんなならどうする？🥺👇\n① デートそっちのけで猫を撫でる\n② 二人で愛でる\n③ お家に連れて帰る",
            "hashtags": "#胸キュン #猫のいる暮らし #癒やし動画 #3Dアニメ",
            "russian_summary": "Хук на видео + милое описание с призывом к подписке + опрос по номерам в первом комменте."
        }
