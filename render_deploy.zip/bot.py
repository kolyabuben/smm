# -*- coding: utf-8 -*-
import os
import sys
import logging
import asyncio

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    ContextTypes,
    filters
)

import config
import ai_generator
import video_editor

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

user_sessions = {}

def get_main_menu_keyboard():
    keyboard = [
        [
            InlineKeyboardButton("🇯🇵 5 Трендовых идей (Япония)", callback_data="ideas_Japan"),
            InlineKeyboardButton("🇩🇪 5 Трендовых идей (Германия)", callback_data="ideas_Germany")
        ],
        [
            InlineKeyboardButton("✂️ Смонтировать видео (Очистка + Звук)", callback_data="action_montage"),
            InlineKeyboardButton("ℹ️ О сценаристе", callback_data="action_help")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "✨ **C4 ANIMORA — Автономный SMM Ассистент (Cloud 24/7)** ✨\n\n"
        "Я работаю в круглосуточном облаке и помогаю создавать вирусные 10-секундные Reels/TikTok:\n\n"
        "🔥 **Алгоритмический тренд-хантер:**\n"
        "Анализирует тренды Instagram/TikTok (Wingman Pet, Kyun-desu, Plot Twist 7s, Cute Aggression) и даёт готовый промпт + хук + хэштеги.\n\n"
        "✂️ **Чистовой монтаж:**\n"
        "Пришлите мне видео (из Kling, Hailuo, Flow) — я бесследно срежу водяной знак, отцентрирую в 9:16 и наложу романтическое фортепиано.\n\n"
        "Выберите действие в меню ниже 👇"
    )
    if update.message:
        await update.message.reply_text(text, parse_mode="Markdown", reply_markup=get_main_menu_keyboard())
    elif update.callback_query:
        await update.callback_query.message.reply_text(text, parse_mode="Markdown", reply_markup=get_main_menu_keyboard())

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    user_id = query.from_user.id

    if data.startswith("ideas_"):
        country = data.split("_")[1]
        c_name = "Японии 🇯🇵" if country == "Japan" else "Германии 🇩🇪"
        await query.message.reply_text(f"🔍 **Анализирую алгоритмические тренды Reels/TikTok для {c_name}...**")
        
        ideas = ai_generator.generate_viral_ideas(country, 5)
        user_sessions[user_id] = {"country": country, "ideas": ideas}
        
        msg = f"📈 **ТОП-5 САМЫХ ТРЕНДОВЫХ КОНЦЕПЦИЙ ({c_name}):**\n\n"
        buttons = []
        for i, item in enumerate(ideas, 1):
            tag = item.get("trend_tag", "🔥 ТРЕНД")
            title = item.get("title", f"Идея #{i}")
            timeline = item.get("timeline", "")
            why_viral = item.get("why_viral", "")
            
            msg += (
                f"**{i}. {title}**\n"
                f"🏷️ _{tag}_\n"
                f"⏱ **Хронометраж:** {timeline}\n"
                f"💡 **Почему залетит:** {why_viral}\n\n"
            )
            buttons.append(InlineKeyboardButton(f"Выбрать #{i}", callback_data=f"pick_{i}"))
        
        kb = [
            buttons[:3],
            buttons[3:],
            [
                InlineKeyboardButton("🔄 Сгенерировать другие тренды", callback_data=f"ideas_{country}"),
                InlineKeyboardButton("🔙 Главное меню", callback_data="menu_main")
            ]
        ]
        await query.message.reply_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(kb))

    elif data.startswith("pick_"):
        idx = int(data.split("_")[1]) - 1
        session = user_sessions.get(user_id, {})
        ideas = session.get("ideas", [])
        country = session.get("country", "Japan")
        
        if 0 <= idx < len(ideas):
            chosen = ideas[idx]
            await query.message.reply_text(f"⚙️ **Формирую полный кинематографичный пакет:**\n_{chosen.get('title')}_...")
            
            pkg = ai_generator.generate_production_package(
                country,
                chosen.get('title', ''),
                chosen.get('timeline', '') or chosen.get('description', '')
            )
            user_sessions[user_id]["chosen"] = chosen
            user_sessions[user_id]["package"] = pkg
            
            response_text = (
                f"🎬 **ГОТОВЫЙ ПАКЕТ ДЛЯ СЪЁМКИ В РЕКОМЕНДАЦИИ**\n"
                f"**Концепция:** {chosen.get('title')}\n"
                f"🏷️ _{chosen.get('trend_tag', '')}_\n\n"
                f"📋 **Промпт для Kling AI / Hailuo AI (скопируй в 1 клик):**\n"
                f"```text\n{pkg.get('prompt', '')}\n```\n\n"
                f"📌 **Хук на видео (On-screen text):**\n`{pkg.get('on_screen_hook', '')}`\n\n"
                f"📝 **Текст описания поста:**\n```text\n{pkg.get('caption', '')}\n```\n\n"
                f"💬 **Закреплённый 1-й комментарий (Опрос по номерам):**\n```text\n{pkg.get('first_comment', '')}\n```\n\n"
                f"🏷️ **Хэштеги алгоритма:**\n`{pkg.get('hashtags', '')}`\n\n"
                f"🇷🇺 **Перевод смыслов:**\n_{pkg.get('russian_summary', '')}_\n\n"
                f"💡 _Сгенерируй ролик в Kling/Hailuo и отправь мне файл в чат — я бесследно уберу водяной знак и наложу музыку!_"
            )
            
            kb = [
                [InlineKeyboardButton("📥 Отправить видео на автомонтаж", callback_data="action_montage")],
                [InlineKeyboardButton("🔙 Главное меню", callback_data="menu_main")]
            ]
            await query.message.reply_text(response_text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(kb))

    elif data == "action_montage":
        text = (
            "✂️ **Автоматический монтаж Reels:**\n\n"
            "Просто **пришли мне видеофайлом** сгенерированный ролик (из Kling AI, Hailuo или другого генератора).\n\n"
            "Я автоматически в облаке:\n"
            "1. Бесследно срежу водяной знак нейросети (смарт-кроп 9:16)\n"
            "2. Доведу качество до 1080×1920 (фильтр Lanczos)\n"
            "3. Наложу романтическое фортепиано с мягким затуханием\n"
            "4. Пришлю готовый файл для публикации!\n\n"
            "Жду видео в чат! 📥"
        )
        kb = [[InlineKeyboardButton("🔙 Главное меню", callback_data="menu_main")]]
        await query.message.reply_text(text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(kb))

    elif data.startswith("montage_org_"):
        parts = data.split("_")
        country = parts[2]
        filename = parts[3]
        src_path = os.path.join(config.INCOMING_DIR, filename)
        
        await query.message.reply_text(f"⏳ **Монтирую органический рилс для {country} (чистовой звук, 9:16, удаление водяного знака)...**")
        try:
            out_file = video_editor.render_organic_reel(src_path, country=country, music_type="piano")
            await query.message.reply_text("✅ **Монтаж завершен! Загружаю видео в чат...**")
            with open(out_file, "rb") as vf:
                await query.message.reply_video(
                    video=vf,
                    caption=f"🎬 **Готовый органический Reels ({country})**\n\nВодяной знак бесследно удалён, музыка сведена, 1080×1920!"
                )
        except Exception as e:
            logger.error("Organic montage error: %s", e)
            await query.message.reply_text(f"❌ Ошибка при монтаже: {e}")

    elif data == "action_help":
        help_text = (
            "🤖 **Как работает облачный SMM-ассистент:**\n\n"
            "• **Trend Hunting Engine:** Модель оценивает текущие тренды Reels/TikTok (Wingman Pet, Kyun-desu, Plot Twist 7s, Cute Aggression).\n"
            "• **Формула удержания:** строго 10 секунд (0-3с шок-хук, 3-7с динамика, 7-10с эмоциональный панчлайн).\n"
            "• **Облачный FFmpeg:** срезает водяные знаки, масштабирует в 1080x1920 и сводит аудио.\n"
            "• **24/7 Uptime:** работает независимо от домашнего ПК и электричества.\n\n"
            "Создано для взрывного роста аккаунтов **C4 Animora** 🎬"
        )
        kb = [[InlineKeyboardButton("🔙 Главное меню", callback_data="menu_main")]]
        await query.message.reply_text(help_text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(kb))

    elif data == "menu_main":
        await start_command(update, context)

async def handle_video(update: Update, context: ContextTypes.DEFAULT_TYPE):
    video = update.message.video or update.message.document
    if not video:
        return
    
    await update.message.reply_text("📥 **Получил видео! Скачиваю в облако...**")
    
    file_obj = await context.bot.get_file(video.file_id)
    filename = f"user_{video.file_unique_id}.mp4"
    save_path = os.path.join(config.INCOMING_DIR, filename)
    await file_obj.download_to_drive(save_path)
    
    text = (
        "✅ **Видео успешно загружено в облако!**\n\n"
        "Под какую страну смонтировать чистовой ролик (без водяных знаков и со звуком)?"
    )
    kb = [
        [
            InlineKeyboardButton("🇯🇵 Органика Япония (Звук + 1080×1920)", callback_data=f"montage_org_Japan_{filename}"),
            InlineKeyboardButton("🇩🇪 Органика Германия (Звук + 1080×1920)", callback_data=f"montage_org_Germany_{filename}")
        ],
        [InlineKeyboardButton("🔙 Отмена", callback_data="menu_main")]
    ]
    await update.message.reply_text(text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(kb))

async def main_async():
    application = ApplicationBuilder().token(config.TELEGRAM_BOT_TOKEN).build()
    
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("menu", start_command))
    application.add_handler(CallbackQueryHandler(handle_callback))
    application.add_handler(MessageHandler(filters.VIDEO | filters.Document.VIDEO, handle_video))
    
    logger.info("Telegram Bot starting polling...")
    await application.initialize()
    await application.start()
    await application.updater.start_polling()
    
    while True:
        await asyncio.sleep(3600)

if __name__ == "__main__":
    asyncio.run(main_async())
